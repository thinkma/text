//
//  LXTHotFix.h
//  LXTHotFix
//
//  Created by apple on 2/25/17.
//  Copyright © 2017 mawei. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LXTHotFix.
FOUNDATION_EXPORT double LXTHotFixVersionNumber;

//! Project version string for LXTHotFix.
FOUNDATION_EXPORT const unsigned char LXTHotFixVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LXTHotFix/PublicHeader.h>


#import "LXTStudentClientVC.h"



