//
//  LXTStudentClientVC.h
//  LXTHotFix
//
//  Created by apple on 2/25/17.
//  Copyright © 2017 mawei. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol LXTStudentClientsDelegate <NSObject>

- (void)enterRoom;

@end


@interface LXTStudentClientVC : UIViewController

@property (nonatomic,assign)id<LXTStudentClientsDelegate> delegate;

+ (void)lxt_initWithUser:(NSString *)userName
                password:(NSString *)password
              schoolCode:(NSString *)code
          viewController:(UIViewController *)viewController;



- (void)lxtStu_initWithUser:(NSString *)userName
                   password:(NSString *)password
                 schoolCode:(NSString *)code
             viewController:(UIViewController *)viewController;

@end
